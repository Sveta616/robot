﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();
        }

        private void button1_Click (object sender, EventArgs e)
        {
            try
            {
                Robot robot1 = new Robot();
                Robot robot2 = new Robot();
                Robot robot3 = new Robot();
                Random rn = new Random();
                int b = rn.Next(0, 100);
                robot1.min(b);
                robot1.kollife = Convert.ToInt32(textBox1.Text);
                label1.Text = "Кол-во жизней робота1 в начале игры" + robot1.kollife;
                robot2.kollife = Convert.ToInt32(textBox2.Text);
                label3.Text = "Кол-во жизней робота2 в начале игры" + robot2.kollife;
                robot3.kollife = Convert.ToInt32(textBox3.Text);
                label5.Text = "Кол-во жизней робота3 в начале игры" + robot3.kollife;
                int a = robot1.kollife;
                robot1.min(robot1.kollife);
                label2.Text = "Кол-во жизней робота1 в конце игры" + Convert.ToString(robot1.getlife());
                robot2.kol(a, robot1.getlife());
                label4.Text = "Кол-во жизней робота2 в конце игры" + Convert.ToString(robot2.getlife());
                robot3.kol(a, robot1.getlife());
                label6.Text = "Кол-во жизней робота3 в конце игры" + Convert.ToString(robot3.getlife());
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("заполните поле");
                }
            } catch
            {
                MessageBox.Show("Введите символ");
            }
        }
    }
}
